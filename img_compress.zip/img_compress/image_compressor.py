import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from skimage import io
from sklearn.utils import shuffle

image= io.imread("C:\\Users\\sairam\\OneDrive\\Desktop\\woman.jpg")
original_shape=image.shape
new_shape=image.reshape(-1,3)
image_sample=shuffle(new_shape,random_state=42)
no_of_clusters=8
kmeans=KMeans(n_clusters=no_of_clusters,init='random',n_init=10,max_iter=1000,random_state=42)
kmeans.fit(image_sample)
labels=kmeans.predict(new_shape)
compressed_image_in_formatted_shape=kmeans.cluster_centers_[labels]

final_compressed_image=compressed_image_in_formatted_shape.reshape(original_shape).astype(np.uint8)
plt.figure(figsize=(10,7))
plt.axis('off')
plt.title("resultant compressed image")
plt.imshow(final_compressed_image)
plt.show()
io.imsave("compressed_img.jpg",final_compressed_image)