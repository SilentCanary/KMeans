import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.utils import shuffle
from skimage import io

image=io.imread("C:\\Users\\sairam\\OneDrive\\Desktop\\woman.jpg")
original_shape=image.shape
image_new=image.reshape(-1,3)
image_sample=shuffle(image_new,random_state=42)[:1000]
inertias=[]
KRange=range(1,20)
for k in KRange:
    kmeans=KMeans(n_clusters=k,init='random',n_init=10,max_iter=1000,random_state=42)
    kmeans.fit(image_sample)
    inertias.append(kmeans.inertia_)
    
plt.figure(figsize=(10,7))
plt.plot(KRange,inertias,marker='o')
plt.xlabel("Number of clusters")
plt.ylabel("Inertia")
plt.title("Elbow method for finding number of clusters")
plt.show()