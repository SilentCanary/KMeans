from sklearn.cluster import KMeans
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN
import matplotlib.pyplot as plt
from sklearn.metrics import silhouette_score
from scipy.cluster.hierarchy import dendrogram, linkage

ratings=pd.read_csv("C:\\Users\\sairam\\Documents\\ML stuff\\ml-latest-small\\ml-latest-small\\ratings.csv")
movies=pd.read_csv("C:\\Users\\sairam\\Documents\\ML stuff\\ml-latest-small\\ml-latest-small\\movies.csv")
print(ratings.head())
print(movies.head())
user_matrix=ratings.pivot(index='userId',columns='movieId',values='rating').fillna(0)
print(user_matrix.head())
initial_users=user_matrix
k=2
kmeans=KMeans(n_clusters=k,max_iter=1000,init='k-means++',random_state=42)
initial_clusters=kmeans.fit(initial_users)
silhouette_avg = silhouette_score(initial_users, initial_clusters.labels_)
print(f"Silhouette Score: {silhouette_avg}")
pca=PCA(n_components=2)
reduced_data=pca.fit_transform(initial_users)
plt.figure(figsize=(10,7))
plt.scatter(reduced_data[:,0],reduced_data[:,1],c=initial_clusters.labels_,cmap='viridis')
plt.title("INITIAL CLUSTERS FORMED")
plt.xlabel("PCA component 1")
plt.ylabel("PCA component 2")
plt.show()

def get_recommendation(clusters,user_id,user_matrix,movies):
    cluster_id=clusters[user_id]
    cluster_users=np.where(clusters==cluster_id)[0]
    cluster_items=user_matrix.iloc[cluster_users].mean(axis=0)
    recommended_movie_ids = cluster_items.sort_values(ascending=False).index[:5]
    recommended_titles = movies[movies['movieId'].isin(recommended_movie_ids)]['title']
    return recommended_titles.tolist()

new_user_id = 97
recommendations = get_recommendation(initial_clusters.labels_, new_user_id, user_matrix, movies)
print("Recommendations for user ",new_user_id," : ")
for title in recommendations:
    print(title)